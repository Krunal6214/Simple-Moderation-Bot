

module.exports = {

    token: process.env.TOKEN, 
    status: 'Never Gonna Give you Up',
    modlogchannel: '1253020395980980287',
    warnlog: '1253020395980980287',
    welcomechannel: '1253020395980980287',
}